import React, { useState, useEffect } from 'react';
import { makeStyles } from "@material-ui/core/styles";
import {
    Grid, Typography, Box, Paper, Table, TableHead, TableBody, TableRow, TableCell,
    TableContainer, TablePagination, Checkbox, Button, Dialog, DialogTitle, DialogContent,
} from "@material-ui/core";
import SearchBar from "material-ui-search-bar";
import { DataGrid } from '@material-ui/data-grid';

// icons 
import EditIcon from '@material-ui/icons/Edit';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import AddIcon from '@material-ui/icons/Add';
import axios from 'axios';
import ClearIcon from '@material-ui/icons/Clear';
import HighlightOffRoundedIcon from '@material-ui/icons/HighlightOffRounded';
import UpdateUser from '../user/UpdateUser';

const useStyles = makeStyles(theme => ({
    cells: {
        fontWeight: "bold",
    }
}))

const Dashboard = () => {
    const classes = useStyles();
    const [users, setUsers] = useState([]);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);

    const [showDialogRegister, setShowDialogRegister] = useState(false)
    const [showDialog, setShowDialog] = useState(false);
    const [deleteDialog, setDeleteDialog] = useState(false);

    // const [user, setUser] = useState();
    const [userID, setUserID] = useState("");
    const [id,setID] = useState(""); 
    
    const loadUsers = async () => {
        console.clear();
        const res = await axios.get('http://localhost:4004/register/fsp');
        setUsers(res.data.data.AllData)
        // console.log(res.data.data.AllData)
    }

    useEffect(() => {
        loadUsers();
    }, []);

    const onChangePage = (event, nextPage) => {
        setPage(nextPage);
    };

    const onChangeRowsPerPage = (event) => {
        setRowsPerPage(event.target.value)
    };

    const updateUserData = async _id => {
        setShowDialog(true)
        setUserID(_id)
    }

    const deleteUser = async () => {
        debugger
        console.log(`Id : ${id} is Deleted`);
        await axios.delete(`http://localhost:4004/register/${id}`);
        loadUsers();
        setDeleteDialog(false)
    }

    const openDeleteDialoBox = () => {
        setDeleteDialog(true);
    }

    const rows = users;
    const columns = [
        {
            field:'id',
            headerName:'Id',
            width:75
        }
        ,{
            field : "fname",
            headerName: "First Name",
            width:150
        },
        {
            field : "lname",
            headerName:"Last Name",
            width:150
        },
        {
            field : "user",
            headerName : "User Name",
            width:150
        },
        {
            field : "email",
            headerName: "Email Addrress",
            width:200
        },
        {
            field : "phone",
            headerName : "Phone Number",
            width:150
        },
        {
            field : "gender",
            headerName:"Gender",
            width:150
        },
        {
            field : "dob",
            headerName:"BirthDate",
            width:150
        },
        {
            field: "states",
            headerName : "State",
            width:150
        },
        {
            field : "city",
            headerName:"City",
            width:150
        },
    ]

    const [currentRow, setCurrentRow] = useState(null);

    return (
        <>
            <Grid container justify="center"  component={Box} pb={10}>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <Typography align="center" variant="h3" gutterBottom>Dashboard</Typography>
                        <Box align='right'>
                        <SearchBar
                            onChange={() => console.log('onChange')}
                            onRequestSearch={() => console.log('onRequestSearch')}
                            style={{maxWidth: '350px', marginBottom:'15px'}}
                        />
                        </Box>
                    </Box>
                   
                   {/* DataGrid */}
                    <Box component={Paper} style={{height:"580px",  width:"100%"}}>
                        <DataGrid 
                            onRowSelected={(item) => {setCurrentRow(item.data); setID(item.data._id)} }
                            rows={rows}
                            columns={columns}
                            pageSize={10}
                            rowsPerPageOptions={[3, 5, 10, 20, 50, 100]}
                            >
                        </DataGrid>
                    </Box>

                    {/* Update Button */}
                    <Button style={{ position: "fixed", bottom: "30px", right: "150px" }}
                        startIcon={<EditIcon />} variant="contained" color="primary" disabled={!currentRow} onClick={() => { updateUserData(users._id) }}>Edit</Button>
                    
                    {/* Update Button */}
                    <Button style={{ position: "fixed", bottom: "30px", right: "25px" }}
                        startIcon={<DeleteForeverIcon />} variant="contained" color="secondary" disabled={!currentRow} onClick={() => { openDeleteDialoBox() }}>Delete</Button>

                    {/* Add New User */}
                    <Button style={{ position: "fixed", bottom: "30px",  left: "25px", borderRadius:"100px" }}
                         variant="contained" color="primary" onClick={() => setShowDialogRegister(true)}><AddIcon /></Button>
                </Grid>
            </Grid>


            {/* {/ add new User /} */}
            <Dialog open={showDialogRegister}>
                <DialogTitle >
                    <div style={{ display: "flex" }}>
                        <Typography variant="h6" style={{ flexGrow: 1 }}>Add New User</Typography>
                        <Button onClick={() => { setShowDialogRegister(false) }}><ClearIcon /></Button>
                    </div>
                </DialogTitle>
                <UpdateUser />
            </Dialog>

            {/* {/ update user /} */}
            <Dialog open={showDialog}>
                <DialogTitle>Update Data User
                    <Button style={{ position: "absolute", right: "10px" }} onClick={() => { setShowDialog(false) }}>
                        <ClearIcon />
                    </Button>
                </DialogTitle>

                <DialogContent>
                    <UpdateUser id={id} />
                </DialogContent>
            </Dialog>

            {/* Delete Dialog-box */}
            <Dialog open={deleteDialog}>
                <DialogContent>
                    <Grid container spacing={2} align="center" justify="space-evenly" style={{ width: "300px" }}>
                        <Grid item lg={12} >
                            <HighlightOffRoundedIcon fontSize="large" color="secondary" />
                        </Grid>
                        <Typography variant="h5" >Are you Sure ?</Typography>
                        <Typography variant="subtitle2" style={{ marginBottom: "25px" }}>You will not be able to recover this record!</Typography>
                        <Grid item lg={6} >
                            <Button color="default" variant="outlined" onClick={() => { setDeleteDialog(false) }}>Cancel</Button>
                        </Grid>
                        <Grid item lg={6}>
                            <Button color="secondary" variant="contained" onClick={() => deleteUser()}>Delete</Button>
                        </Grid>
                    </Grid>
                </DialogContent>
            </Dialog>

        </>)
}

export default Dashboard;
